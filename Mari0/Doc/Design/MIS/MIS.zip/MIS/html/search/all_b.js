var searchData=
[
  ['newgame',['NewGame',['../class_main_menu.html#a0b9845990e48b948575d2bf6f4dad24d',1,'MainMenu']]]
];
