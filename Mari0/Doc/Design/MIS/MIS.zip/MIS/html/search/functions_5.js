var searchData=
[
  ['oncollisionenter2d',['OnCollisionEnter2D',['../class_enemy_a_i.html#afc64d92a7e7ab85f3f25aff102898bf5',1,'EnemyAI.OnCollisionEnter2D()'],['../class_question_block.html#a1df9f4d15e5930ea85009cbfd66af692',1,'QuestionBlock.OnCollisionEnter2D()']]],
  ['ontriggerenter2d',['OnTriggerEnter2D',['../class_pause.html#a78f4fd954f35b497f3c6b2d40897206d',1,'Pause.OnTriggerEnter2D()'],['../class_portal.html#a168c1b61f11d31c85c40f829104b39f5',1,'Portal.OnTriggerEnter2D()'],['../class_unity_standard_assets_1_1__2_d_1_1_win_condition.html#a346fb1b61e086fc67d92cebf89121ec6',1,'UnityStandardAssets._2D.WinCondition.OnTriggerEnter2D()']]],
  ['ontriggerexit2d',['OnTriggerExit2D',['../class_portal.html#a8a00fc60612d793ce13b458f40dd2050',1,'Portal']]]
];
