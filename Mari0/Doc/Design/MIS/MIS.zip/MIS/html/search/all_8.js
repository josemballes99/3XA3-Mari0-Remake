var searchData=
[
  ['isdead',['isDead',['../class_pause.html#ada271a606725dec7ffed7f1e24f00fa2',1,'Pause']]],
  ['isinportal',['isInPortal',['../class_portal.html#a646f74c4ec73bb9e215cc6b1f2ee7613',1,'Portal']]],
  ['iskilled',['isKilled',['../class_enemy_a_i.html#a66c04f8c156aaaccdb36837df7c1fb3c',1,'EnemyAI']]],
  ['ispaused',['isPaused',['../class_pause.html#ae845c846c4be05e29c8948089f57eec0',1,'Pause']]]
];
