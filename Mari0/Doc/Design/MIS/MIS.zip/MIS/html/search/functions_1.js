var searchData=
[
  ['ontriggerenter2d',['OnTriggerEnter2D',['../class_portal.html#a168c1b61f11d31c85c40f829104b39f5',1,'Portal']]],
  ['ontriggerexit2d',['OnTriggerExit2D',['../class_portal.html#a8a00fc60612d793ce13b458f40dd2050',1,'Portal']]]
];
