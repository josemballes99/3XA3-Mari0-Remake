var searchData=
[
  ['awake',['Awake',['../class_unity_standard_assets_1_1__2_d_1_1_platformer2_d_user_control.html#a6561f50503561fcc0757ab54f6fe4ae2',1,'UnityStandardAssets._2D.Platformer2DUserControl.Awake()'],['../class_portal_gun.html#a9861778454f3fceedc3140107c55a824',1,'PortalGun.Awake()']]]
];
