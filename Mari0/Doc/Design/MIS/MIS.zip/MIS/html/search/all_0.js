var searchData=
[
  ['awake',['Awake',['../class_unity_standard_assets_1_1__2_d_1_1_platformer2_d_user_control.html#a6561f50503561fcc0757ab54f6fe4ae2',1,'UnityStandardAssets._2D.Platformer2DUserControl.Awake()'],['../class_unity_standard_assets_1_1__2_d_1_1_platformer_character2_d.html#ab08545ea1f77b02f2bdc0942db144705',1,'UnityStandardAssets._2D.PlatformerCharacter2D.Awake()']]]
];
