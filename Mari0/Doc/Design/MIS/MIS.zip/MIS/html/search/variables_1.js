var searchData=
[
  ['damping',['damping',['../class_unity_standard_assets_1_1__2_d_1_1_camera2_d_follow.html#a47713bd9650a293b93861d1ff0128dd2',1,'UnityStandardAssets::_2D::Camera2DFollow']]],
  ['deadcanvas',['deadCanvas',['../class_pause.html#a12f1bae334858d493b9681282afcb4a6',1,'Pause']]]
];
