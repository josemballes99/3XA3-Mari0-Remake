var searchData=
[
  ['charinthisportal',['charInThisPortal',['../class_portal.html#af563e395a6a5f9606c97bee2a5f50714',1,'Portal']]]
];
