var searchData=
[
  ['orangeportal',['orangePortal',['../class_portal_gun.html#afab2a30b111b6b695802d39975a6d75f',1,'PortalGun']]],
  ['orangeportalcoll',['orangePortalColl',['../class_portal_gun.html#a754773dd18f21b7dacd40e11ce037696',1,'PortalGun']]],
  ['othrportal',['othrPortal',['../class_portal.html#a75f9f3157958a4b2e2c4b4676fb6d73f',1,'Portal']]]
];
