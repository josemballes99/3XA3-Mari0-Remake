var searchData=
[
  ['teleport',['teleport',['../class_portal.html#ab65ffa3f9ccaf636342a6e5878d08b8a',1,'Portal']]]
];
