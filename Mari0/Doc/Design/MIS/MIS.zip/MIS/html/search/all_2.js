var searchData=
[
  ['camera2dfollow',['Camera2DFollow',['../class_unity_standard_assets_1_1__2_d_1_1_camera2_d_follow.html',1,'UnityStandardAssets::_2D']]],
  ['charinthisportal',['charInThisPortal',['../class_portal.html#af563e395a6a5f9606c97bee2a5f50714',1,'Portal']]]
];
