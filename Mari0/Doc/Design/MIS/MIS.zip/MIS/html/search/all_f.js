var searchData=
[
  ['resume',['Resume',['../class_pause.html#a1d1652c23fb2bab829e6d3f7e76727ec',1,'Pause']]]
];
