var searchData=
[
  ['update',['Update',['../class_unity_standard_assets_1_1__2_d_1_1_platformer2_d_user_control.html#a26a896ddc4670988cbb8166ce93ee11e',1,'UnityStandardAssets::_2D::Platformer2DUserControl']]]
];
