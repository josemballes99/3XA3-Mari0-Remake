var searchData=
[
  ['orangeportal',['orangePortal',['../class_portal_gun.html#a6e0fab50b879bfce7cda88a1699c27b8',1,'PortalGun']]],
  ['orangeportalcoll',['orangePortalColl',['../class_portal_gun.html#a754773dd18f21b7dacd40e11ce037696',1,'PortalGun']]]
];
