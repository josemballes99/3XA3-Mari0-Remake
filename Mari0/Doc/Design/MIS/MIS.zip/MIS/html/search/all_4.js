var searchData=
[
  ['ontriggerenter2d',['OnTriggerEnter2D',['../class_portal.html#a168c1b61f11d31c85c40f829104b39f5',1,'Portal']]],
  ['ontriggerexit2d',['OnTriggerExit2D',['../class_portal.html#a8a00fc60612d793ce13b458f40dd2050',1,'Portal']]],
  ['orangeportal',['orangePortal',['../class_portal_gun.html#a6e0fab50b879bfce7cda88a1699c27b8',1,'PortalGun']]],
  ['orangeportalcoll',['orangePortalColl',['../class_portal_gun.html#a754773dd18f21b7dacd40e11ce037696',1,'PortalGun']]]
];
